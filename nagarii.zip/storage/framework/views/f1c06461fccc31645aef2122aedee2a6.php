<?php $__env->startSection('container'); ?>
<div class="container">
    <nav aria-label="breadcrumb" class="my-4">
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="/">Home</a></li>
          <li class="breadcrumb-item active" aria-current="page">Geografis</li>
        </ol>
    </nav>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/aliefadha/codingg/web-dev/laravel/nagarii/resources/views/profil/geografis.blade.php ENDPATH**/ ?>