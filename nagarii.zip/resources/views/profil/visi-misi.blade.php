@extends('layouts.main')

@section('container')
<div class="container">
    <nav aria-label="breadcrumb" class="my-4">
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href=/">Home</a></li>
          <li class="breadcrumb-item active" aria-current="page">Visi Misi</li>
        </ol>
    </nav>
</div>
@endsection